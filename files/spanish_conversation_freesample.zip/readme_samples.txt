Linguaposta.com
Thank you for downloading a free sample at Linguaposta.com. We really hope that you enjoy using this taster - let us know what you think by reviewing it or sending us a message at linguaposta.com.

In this .zip package
This package contains two versions of the sample, A4 and US Letter. Use the size that matches the paper in your printer. Generally if you are in North America, you'll use the Us Letter size, if you are in Australia, New Zealand, UK or Ireland then you'll most likely use the A4 version.
